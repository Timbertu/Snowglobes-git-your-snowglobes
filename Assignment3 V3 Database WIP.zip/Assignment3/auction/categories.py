from flask import Blueprint, redirect, url_for, request, session, render_template
from .models import Listing, User
from . import db
from werkzeug.utils import secure_filename 
import os
from flask_login import login_required, current_user

#Use of blue print to group routes, 
# name - first argument is the blue print name 
# import name - second argument - helps identify the root url for it 
bp = Blueprint('category', __name__,)

@bp.route('/fancy', methods=['GET','POST'])
def fancy():
    return render_template('fancy.html')

@bp.route('/novelty', methods=['GET','POST'])
def novelty():
    return render_template('watchlist.html')

@bp.route('/mundane', methods=['GET','POST'])
def mundane():
    return render_template('watchlist.html')