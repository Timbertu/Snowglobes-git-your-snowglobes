from flask import Blueprint, redirect, url_for, request, session, render_template
from .models import Listing, User, Watchlist, Bidding
from .forms import ListingForm, BiddingForm, WatchlistAddForm, WatchlistRemForm
from . import db
from werkzeug.utils import secure_filename
import os
from flask_login import login_required, current_user

bp = Blueprint('main', __name__)


@bp.route('/')
def index():
    listings = Listing.query.all()
    return render_template('home.html', listings=listings)

@bp.route('/fancy')
def fancy():
    listings = Listing.query.all()
    return render_template('fancy.html', listings=listings)


@bp.route('/watchlist')
@login_required
def watchlist():
    return render_template('watchlist.html')


@bp.route('/')
def search():
    if request.args['search']:
        list = "%" + request.args['search'] + '%'
        listings = Listing.query.filter(Listing.name.like(list)).all()
        return render_template('home.html', listings=listings)
    else:
        return redirect(url_for('main.index'))
