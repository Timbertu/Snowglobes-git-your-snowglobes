from flask import Blueprint, redirect, url_for, request, session, render_template
from .models import Listing, User
from .forms import ListingForm
from . import db
from werkzeug.utils import secure_filename 
import os
from flask_login import login_required, current_user

#Use of blue print to group routes, 
# name - first argument is the blue print name 
# import name - second argument - helps identify the root url for it 
bp = Blueprint('listing', __name__, url_prefix='/listings')

@bp.route('/<id>') 
def show(id): 
  listing = Listing.query.filter_by(id=id).first() 
  return render_template('listings/show.html', listing=listing)
      
def check_upload_file(form):
  fp = form.image.data
  filename = fp.filename
  BASE_PATH = os.path.dirname(__file__)

  upload_path = os.path.join(BASE_PATH, 'static/image', secure_filename(filename))
  db_upload_path = '/static/image/'+ secure_filename(filename)
  fp.save(upload_path)
  return db_upload_path

@bp.route('/create', methods = ['GET', 'POST'])
@login_required
def create():
  form = ListingForm()
  print('Method type: ', request.method)
  if form.validate_on_submit():
    db_file_path = check_upload_file(form)
    listing = Listing(name=form.name.data,
                    size=form.size.data,
                    origin=form.origin.data,
                    colour=form.colour.data,
                    age=form.age.data,
                    category=form.category.data,          
                    description=form.description.data,
                    startbid=form.startbid.data,
                    image=db_file_path)
    # add the object to the db session
    db.session.add(listing)
    # commit to the database
    db.session.commit()
    return redirect(url_for('listing.create'))
  return render_template('listings/create.html', form=form)