from . import db
from datetime import datetime
from flask_login import UserMixin

class User(db.Model, UserMixin):
    __tablename__='users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), index=True, unique=True, nullable=False)
    emailid = db.Column(db.String(100), index=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

class Listing(db.Model):
    __tablename__ = 'listings'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))
    size = db.Column(db.String(50))
    origin = db.Column(db.String(200))
    colour = db.Column(db.String(100))
    age = db.Column(db.Integer)
    category = db.Column(db.String(100))
    description = db.Column(db.String(200))
    startbid = db.Column(db.Integer)
    image = db.Column(db.String(400))
    upost = db.Column(db.String(30), db.ForeignKey('users.name'))
    created_at = db.Column(db.DateTime, default=datetime.now())
    def __repr__(self): #string print method
        return "<Name: {}>".format(self.name)

class Bidding(db.Model):
    __tablename__ = 'bids'
    id = db.Column(db.Integer, primary_key=True)
    amount = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.now())
    sbid = db.Column(db.Integer, db.ForeignKey('listings.startbid'))
    ubid = db.Column(db.String(100), db.ForeignKey('users.name'))
    lid = db.Column(db.Integer, db.ForeignKey('listings.id'))
    def __repr__(self): #string print method
        return "<Bid: {}>".format(self.name)