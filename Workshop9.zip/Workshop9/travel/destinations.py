from flask import Blueprint, redirect, url_for, request, session, render_template
from .models import Destination,Comment, User
from .forms import DestinationForm, CommentForm
from . import db
from werkzeug.utils import secure_filename 
import os
from flask_login import login_required, current_user

#Use of blue print to group routes, 
# name - first argument is the blue print name 
# import name - second argument - helps identify the root url for it 
bp = Blueprint('destination', __name__, url_prefix='/destinations')

@bp.route('/<id>') 
def show(id): 
  destination = Destination.query.filter_by(id=id).first() 
  cform = CommentForm() # create the comment form and passit to render_template
  #in the html this is access as a varible named form
  return render_template('destinations/show.html', destination=destination, form=cform)

@bp.route('/<id>/comment', methods = ['GET', 'POST'])
@login_required
def comment(id):  
    form = CommentForm()  
    #get the destination object associated to the page and the comment
    destination_obj = Destination.query.filter_by(id=id).first()  
    if form.validate_on_submit():  
      #read the comment from the form
      comment = Comment(text=form.text.data,  
                        destination=destination_obj, user=current_user) 
      #here the back-referencing works - comment.destination is set
      # and the link is created
      db.session.add(comment) 
      db.session.commit() 

      #flashing a message which needs to be handled by the html
      #flash('Your comment has been added', 'success')  
      print('Your comment has been added', 'success') 
    # using redirect sends a GET request to destination.show
      return redirect(url_for('destination.show', id=id))
      
def check_upload_file(form):
  fp = form.image.data
  filename = fp.filename
  BASE_PATH = os.path.dirname(__file__)

  upload_path = os.path.join(BASE_PATH, 'static/image', secure_filename(filename))
  db_upload_path = '/static/image/'+ secure_filename(filename)
  fp.save(upload_path)
  return db_upload_path

@bp.route('/create', methods = ['GET', 'POST'])
@login_required
def create():
  form = DestinationForm()
  print('Method type: ', request.method)
  if form.validate_on_submit():
    db_file_path = check_upload_file(form)
    destination = Destination(name=form.name.data,
                              description=form.description.data,
                              image=db_file_path,
                              currency=form.currency.data)
    # add the object to the db session
    db.session.add(destination)
    # commit to the database
    db.session.commit()
    return redirect(url_for('destination.create'))
  return render_template('destinations/create.html', form=form)